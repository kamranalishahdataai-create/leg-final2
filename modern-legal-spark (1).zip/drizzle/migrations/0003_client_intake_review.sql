CREATE TABLE public.client_intakes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL,
 status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','needs_information','conflict_cleared','compliance_review','ready_for_engagement','closed')),
 details jsonb NOT NULL, identity jsonb, client_message text NOT NULL DEFAULT '', version text NOT NULL DEFAULT '2026-10-21',
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.client_intakes TO authenticated;
GRANT ALL ON public.client_intakes TO service_role;
ALTER TABLE public.client_intakes ENABLE ROW LEVEL SECURITY;
CREATE POLICY intake_read ON public.client_intakes FOR SELECT TO authenticated USING (user_id=auth.uid() OR EXISTS (SELECT 1 FROM public.current_user_roles WHERE role='admin'));
CREATE POLICY intake_insert ON public.client_intakes FOR INSERT TO authenticated WITH CHECK (user_id=auth.uid() AND status='submitted' AND identity IS NULL AND client_message='');
CREATE POLICY intake_update ON public.client_intakes FOR UPDATE TO authenticated USING (user_id=auth.uid() OR EXISTS (SELECT 1 FROM public.current_user_roles WHERE role='admin')) WITH CHECK (user_id=auth.uid() OR EXISTS (SELECT 1 FROM public.current_user_roles WHERE role='admin'));
CREATE INDEX client_intakes_owner ON public.client_intakes(user_id,created_at DESC);
CREATE TABLE public.intake_reviews (
 intake_id uuid PRIMARY KEY REFERENCES public.client_intakes(id), notes text NOT NULL DEFAULT '', conflict_checked boolean NOT NULL DEFAULT false,
 identification_checked boolean NOT NULL DEFAULT false, verification text NOT NULL DEFAULT 'pending' CHECK (verification IN ('pending','not_required','exempt','completed')),
 verification_record text NOT NULL DEFAULT '', organization_checked boolean NOT NULL DEFAULT false, third_party_checked boolean NOT NULL DEFAULT false,
 funds_checked boolean NOT NULL DEFAULT false, monitoring_record text NOT NULL DEFAULT '', reviewed_by uuid, reviewed_at timestamptz
);
GRANT SELECT, INSERT, UPDATE ON public.intake_reviews TO authenticated;
GRANT ALL ON public.intake_reviews TO service_role;
ALTER TABLE public.intake_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY review_admin ON public.intake_reviews FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM public.current_user_roles WHERE role='admin')) WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles WHERE role='admin'));
CREATE TABLE public.intake_events (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), intake_id uuid NOT NULL REFERENCES public.client_intakes(id), actor_id uuid NOT NULL,
 action text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.intake_events TO authenticated;
GRANT ALL ON public.intake_events TO service_role;
ALTER TABLE public.intake_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY events_admin ON public.intake_events FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.current_user_roles WHERE role='admin'));
CREATE OR REPLACE FUNCTION public.guard_client_intake() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
DECLARE staff boolean; r public.intake_reviews;
BEGIN
 SELECT EXISTS(SELECT 1 FROM public.current_user_roles WHERE role='admin') INTO staff;
 IF jsonb_typeof(NEW.details) IS DISTINCT FROM 'object' OR length(NEW.details::text)>20000 OR NEW.details->>'consent' IS DISTINCT FROM 'true' OR coalesce(length(trim(NEW.details->>'legalName')),0)<2 OR coalesce(length(trim(NEW.details->>'email')),0)<3 OR coalesce(length(trim(NEW.details->>'phone')),0)<7 OR coalesce(length(trim(NEW.details->>'area')),0)=0 OR coalesce(length(trim(NEW.details->>'jurisdiction')),0)=0 OR NEW.details->>'purpose' NOT IN ('membership','matter','both') OR NEW.details->>'clientType' NOT IN ('individual','organization') THEN RAISE EXCEPTION 'Incomplete intake details'; END IF;
 IF NEW.details->>'clientType'='organization' AND (coalesce(length(trim(NEW.details->>'organization')),0)=0 OR coalesce(length(trim(NEW.details->>'authority')),0)=0) THEN RAISE EXCEPTION 'Organization and authority required'; END IF;
 IF jsonb_typeof(NEW.details->'parties') IS DISTINCT FROM 'array' THEN RAISE EXCEPTION 'Party list required'; END IF;
 IF (jsonb_array_length(NEW.details->'parties')=0 AND NEW.details->>'noOtherParties' IS DISTINCT FROM 'true') OR (jsonb_array_length(NEW.details->'parties')>0 AND NEW.details->>'noOtherParties'='true') THEN RAISE EXCEPTION 'Confirm parties'; END IF;
 IF NEW.identity IS NOT NULL AND (jsonb_typeof(NEW.identity) IS DISTINCT FROM 'object' OR length(NEW.identity::text)>30000 OR NEW.identity->>'accuracy' IS DISTINCT FROM 'true' OR coalesce(length(trim(NEW.identity->>'address')),0)<8 OR coalesce(length(trim(NEW.identity->>'occupation')),0)<2) THEN RAISE EXCEPTION 'Incomplete identification details'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.user_id IS DISTINCT FROM auth.uid() OR NEW.status<>'submitted' OR NEW.identity IS NOT NULL OR NEW.client_message<>'' THEN RAISE EXCEPTION 'Requests begin with conflict review'; END IF;
 ELSE
  IF NEW.id IS DISTINCT FROM OLD.id OR NEW.user_id IS DISTINCT FROM OLD.user_id OR NEW.created_at IS DISTINCT FROM OLD.created_at OR NEW.version IS DISTINCT FROM OLD.version THEN RAISE EXCEPTION 'Intake ownership and version are immutable'; END IF;
  IF NOT staff THEN
   IF NEW.client_message IS DISTINCT FROM OLD.client_message THEN RAISE EXCEPTION 'Staff message is protected'; END IF;
   IF OLD.status='needs_information' AND OLD.identity IS NULL AND NEW.status='submitted' AND NEW.identity IS NULL THEN NULL;
   ELSIF (OLD.status='conflict_cleared' OR (OLD.status='needs_information' AND OLD.identity IS NOT NULL)) AND NEW.status='compliance_review' AND NEW.identity IS NOT NULL AND NEW.details IS NOT DISTINCT FROM OLD.details THEN NULL;
   ELSE RAISE EXCEPTION 'Only requested intake information may be submitted'; END IF;
  END IF;
  IF NEW.status IN ('conflict_cleared','ready_for_engagement') AND NEW.status IS DISTINCT FROM OLD.status THEN
   SELECT * INTO r FROM public.intake_reviews WHERE intake_id=NEW.id;
   IF NOT staff OR r.conflict_checked IS DISTINCT FROM true OR length(trim(coalesce(r.notes,'')))=0 THEN RAISE EXCEPTION 'Recorded human conflict review required'; END IF;
   IF NEW.status='ready_for_engagement' AND (NEW.identity IS NULL OR r.identification_checked IS DISTINCT FROM true OR r.verification='pending' OR r.verification IS NULL OR length(trim(coalesce(r.verification_record,'')))=0 OR r.organization_checked IS DISTINCT FROM true OR r.third_party_checked IS DISTINCT FROM true OR r.funds_checked IS DISTINCT FROM true OR length(trim(coalesce(r.monitoring_record,'')))=0) THEN RAISE EXCEPTION 'Complete the identification and applicable compliance review first'; END IF;
  END IF;
 END IF;
 NEW.updated_at=now(); RETURN NEW;
END $$;
CREATE TRIGGER guard_client_intake BEFORE INSERT OR UPDATE ON public.client_intakes FOR EACH ROW EXECUTE FUNCTION public.guard_client_intake();
CREATE OR REPLACE FUNCTION public.audit_client_intake() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 INSERT INTO public.intake_events(intake_id,actor_id,action) VALUES (NEW.id,auth.uid(),CASE WHEN TG_OP='INSERT' THEN 'submitted' WHEN NEW.status IS DISTINCT FROM OLD.status THEN OLD.status||' -> '||NEW.status ELSE 'record updated' END);
 RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.audit_client_intake() FROM PUBLIC,anon,authenticated;
CREATE TRIGGER audit_client_intake AFTER INSERT OR UPDATE ON public.client_intakes FOR EACH ROW EXECUTE FUNCTION public.audit_client_intake();
CREATE OR REPLACE FUNCTION public.stamp_intake_review() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN NEW.reviewed_by=auth.uid(); NEW.reviewed_at=now(); RETURN NEW; END $$;
CREATE TRIGGER stamp_intake_review BEFORE INSERT OR UPDATE ON public.intake_reviews FOR EACH ROW EXECUTE FUNCTION public.stamp_intake_review();