-- Replace security-definer function calls inside RLS policies with caller-scoped views.
-- The private.has_role / private.is_lawyer helpers stay locked to service_role only,
-- but policies no longer need to execute them, so signed-in and signed-out reads work again.

create or replace view public.current_user_roles as
  select ur.role
  from public.user_roles ur
  where ur.user_id = auth.uid();

create or replace view public.current_lawyer_active as
  select l.id
  from public.lawyers l
  where l.user_id = auth.uid()
    and l.is_active = true;

GRANT SELECT ON public.current_user_roles TO anon, authenticated;
GRANT ALL ON public.current_user_roles TO service_role;
GRANT SELECT ON public.current_lawyer_active TO anon, authenticated;
GRANT ALL ON public.current_lawyer_active TO service_role;

-- analytics_events
DROP POLICY IF EXISTS "Admins can view analytics" ON public.analytics_events;
CREATE POLICY "Admins can view analytics" ON public.analytics_events FOR SELECT TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- blog_posts
DROP POLICY IF EXISTS "Admins can manage blog posts" ON public.blog_posts;
CREATE POLICY "Admins can manage blog posts" ON public.blog_posts FOR ALL TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- case_analyses
DROP POLICY IF EXISTS "Admins can view all case analyses" ON public.case_analyses;
CREATE POLICY "Admins can view all case analyses" ON public.case_analyses FOR SELECT TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- community_referrals
DROP POLICY IF EXISTS "Admins can delete referrals" ON public.community_referrals;
CREATE POLICY "Admins can delete referrals" ON public.community_referrals FOR DELETE TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));
DROP POLICY IF EXISTS "Admins can update referrals" ON public.community_referrals;
CREATE POLICY "Admins can update referrals" ON public.community_referrals FOR UPDATE TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));
DROP POLICY IF EXISTS "Admins can view all referrals" ON public.community_referrals;
CREATE POLICY "Admins can view all referrals" ON public.community_referrals FOR SELECT TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- consultations
DROP POLICY IF EXISTS "Admins can view all consultations" ON public.consultations;
CREATE POLICY "Admins can view all consultations" ON public.consultations FOR SELECT TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- contract_templates
DROP POLICY IF EXISTS "Admins can manage templates" ON public.contract_templates;
CREATE POLICY "Admins can manage templates" ON public.contract_templates FOR ALL TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- faqs
DROP POLICY IF EXISTS "Admins can manage FAQs" ON public.faqs;
CREATE POLICY "Admins can manage FAQs" ON public.faqs FOR ALL TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- lawyer_case_assignments
DROP POLICY IF EXISTS "Admins can manage all assignments" ON public.lawyer_case_assignments;
CREATE POLICY "Admins can manage all assignments" ON public.lawyer_case_assignments FOR ALL TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- lawyer_referral_requests
DROP POLICY IF EXISTS "Admins can update referral requests" ON public.lawyer_referral_requests;
CREATE POLICY "Admins can update referral requests" ON public.lawyer_referral_requests FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));
DROP POLICY IF EXISTS "Admins can view all referral requests" ON public.lawyer_referral_requests;
CREATE POLICY "Admins can view all referral requests" ON public.lawyer_referral_requests FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- lawyers
DROP POLICY IF EXISTS "Admins can manage lawyers" ON public.lawyers;
CREATE POLICY "Admins can manage lawyers" ON public.lawyers FOR ALL TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- monthly_reports
DROP POLICY IF EXISTS "Admins can manage reports" ON public.monthly_reports;
CREATE POLICY "Admins can manage reports" ON public.monthly_reports FOR ALL TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));
DROP POLICY IF EXISTS "Lawyers can view reports" ON public.monthly_reports;
CREATE POLICY "Lawyers can view reports" ON public.monthly_reports FOR SELECT TO public
  USING (EXISTS (SELECT 1 FROM public.current_lawyer_active));

-- price_match_requests
DROP POLICY IF EXISTS "Only admins can view price match requests" ON public.price_match_requests;
CREATE POLICY "Only admins can view price match requests" ON public.price_match_requests FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- profiles
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- reviews
DROP POLICY IF EXISTS "Admins can manage reviews" ON public.reviews;
CREATE POLICY "Admins can manage reviews" ON public.reviews FOR ALL TO public
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));

-- user_roles
DROP POLICY IF EXISTS "Admins can view all roles" ON public.user_roles;
CREATE POLICY "Admins can view all roles" ON public.user_roles FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));
DROP POLICY IF EXISTS "Only admins can delete roles" ON public.user_roles;
CREATE POLICY "Only admins can delete roles" ON public.user_roles FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));
DROP POLICY IF EXISTS "Only admins can insert roles" ON public.user_roles;
CREATE POLICY "Only admins can insert roles" ON public.user_roles FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));
DROP POLICY IF EXISTS "Only admins can update roles" ON public.user_roles;
CREATE POLICY "Only admins can update roles" ON public.user_roles FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role))
  WITH CHECK (EXISTS (SELECT 1 FROM public.current_user_roles cur WHERE cur.role = 'admin'::app_role));