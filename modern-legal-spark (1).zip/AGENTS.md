# Project guidance
- Keep client intake separate from membership activation and matter acceptance; stage conflict names before identification, with admin-only human review, server-enforced transitions and private staff records so client submissions cannot self-clear conflicts or activate billing.
- Keep additive intake table types in the intake API module until managed schema types refresh; this shares the existing authenticated client without editing generated integration files.
- Share Rogers, Bell and TELUS concept journeys through TelecomPartnership and carrier data with scoped semantic palettes; preserve carrier-specific benefits while keeping proposals consistent without changing real entitlements.
- Keep Rogers demo customer fees in a proposal-only data helper, separate from checkout and live entitlements, so carrier-funded examples cannot activate or change billing.
- Render Rogers visual story scenes through StorylineDemo using the same walkthrough steps and shared package allowances; illustrative screens must never create live accounts, billing or matters.
- Keep carrier-proposal scope (which personal services are excluded but loyalty-discounted, which corporate packages are offered) in the partnershipScope data module and render it from the shared partnership component; this keeps every carrier page stating the same exclusions without editing copy in three places.

- Share the Professional monthly research allowance through caseResearch across plan cards, comparison and checkout; this prevents conflicting entitlements.
- Classify account and workspace experiences in Layout and scope their visual rhythm globally; public page spacing must not overwhelm operational screens.

- Keep the entry landing page at `/` separate from the full site at `/home`; this gives visitors a concise introduction without replacing the existing service experience.
- Share the entry page's editorial typography and restrained surfaces through `.landing-page` and `.site-shell`, keeping photographic treatments explicit in page heroes; this maintains a consistent public website without altering business logic.
- Classify shared Layout pages as home, subpage, or policy and keep visual rhythm in global scoped CSS and shared UI primitives; this refreshes every route consistently without changing business logic or widening readable policy and form layouts.
- Keep each page hero's image import and shade class separate; this allows the entry page and full website to retain related styling without sharing an identical background.
- RLS policy expressions must only call functions the requesting role can execute; put role and status checks behind caller-scoped views (for example `public.current_user_roles`, `public.current_lawyer_active`) instead of security-definer helpers that stay locked to server-side roles, because a policy calling a non-executable function fails the whole query for every visitor.
- Share practice disclosures and fee scopes through the practiceTerms data module and legal notice primitives; this keeps public pages and policies consistent when approved values change.
- Keep the curated FAQ copy authoritative until hosted FAQ content is reviewed; older records must not replace compliance-corrected answers.
- Retire the community reward entry points and notification endpoint without deleting historical referral records; this removes rewards while preserving existing matter history.
- Do not simulate successful subscriptions or collect card details in the non-integrated checkout; payment activation must wait for a real payment integration.
- Gate member-only features on the `public.memberships` table via `useMembership`; admins record memberships in the dashboard after offline payment arrangements, since checkout cannot activate them.
- Keep Ontario claim formatting logic (Form 7A / Form 14A structure, $35,000 Small Claims limit, disclaimers) in src/lib/claimFormatter.ts so the page, document generator and tests share one source.
- Render the shared Claim Drafter trigger below the research section on the Case Law Research Tool page, so it reads as the step after searching; keep it visible to everyone and document generation gated by membership.
